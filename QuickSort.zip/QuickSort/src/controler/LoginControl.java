package controler;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.paint.Color;
import javafx.scene.layout.BorderPane;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;
import lista.Lista;
public class LoginControl {
    @FXML
    private Button btAceptar;

    @FXML
    private Button btRegistrar;

    @FXML
    private Label lbContra;

    @FXML
    private Label lbUser;

    @FXML
    private Label lbUser1;

    @FXML
    private PasswordField txtContra;

    @FXML
    private TextField txtUser;

    @FXML
    void MouseAceptarEncima(MouseEvent event) {
        btAceptar.setStyle("-fx-background-color: #C21010;");
        btAceptar.setTextFill(Color.WHITE);
    }

    @FXML
    void MouseAceptarSalir(MouseEvent event) {
        btAceptar.setStyle("-fx-background-color: black;");
        btAceptar.setTextFill(Color.WHITE);
    }

    @FXML
    void btRegistrarEncima(MouseEvent event) {
        btRegistrar.setStyle("-fx-background-color: #C21010;");
        btRegistrar.setTextFill(Color.WHITE);
    }

    @FXML
    void btRegistrarEncimaAbajo(MouseEvent event) {
        btRegistrar.setStyle("-fx-background-color: black;");
        btRegistrar.setTextFill(Color.WHITE);
    }

    @FXML
    void clickAceptar(MouseEvent event) {
        String user = txtUser.getText();
        String contra = txtContra.getText();
        if (user.equals("luis") && contra.equals("123")) {
            lbUser1.setText("Correcto");
            abrirContenido();
        } else {
            lbUser1.setText("Usuario y/o contraseña incorrectos");
        }
    }
    @FXML
    void clickLimpiar(MouseEvent event) {
    	txtContra.setText("");
    	txtUser.setText("");
    	lbUser1.setText("");
    }
    private void abrirContenido() {
        try {
            Stage primaryStage = (Stage) btAceptar.getScene().getWindow();
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/contenido.fxml"));
            BorderPane root = loader.load();

            ContenidoControl contenidoControl = loader.getController();
            Lista lista= new Lista();
            contenidoControl.setLista(lista);
            Scene scene = new Scene(root);
            primaryStage.setScene(scene);
            primaryStage.setResizable(false);
            primaryStage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
