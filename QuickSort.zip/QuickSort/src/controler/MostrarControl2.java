package controler;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.input.MouseEvent;
import lista.Lista;
import lista.Datos;
import java.util.List;

public class MostrarControl2 {
	Lista lista;

    @FXML
    private TableColumn<Lista, String> apellido;
    @FXML
    private Button btMostrar;

    @FXML
    private TableColumn<Lista, String> color;

    @FXML
    private TableColumn<Lista, Integer> id;

    @FXML
    private Label mensajeError;

    @FXML
    private TableColumn<Lista, String> modelo;

    @FXML
    private TableColumn<Lista, String> nombre;

    @FXML
    private TableColumn<Lista, Double> precio;

    @FXML
    private TableView<?> tabla;

    @FXML
    void clickMostrar(MouseEvent event) {
        Lista lista = new Lista();
        double precio = 12.2;
        Integer id = 32;
        Datos datos = new Datos("z", "z", "z", "z", precio, id);
        Datos datos2 = new Datos("y", "y", "y", "y", precio, id);
        lista.insertar(datos);
        lista.insertar(datos2);

        // Obtener los nodos de la lista enlazada
        List<Datos> dataList = lista.getNodos();

        // Convertir la lista de nodos en un ObservableList
        ObservableList<Datos> observableList = FXCollections.observableArrayList(dataList);

        // Utilizar el ObservableList como desees
        
        // Por ejemplo, puedes asignarlo a una tabla
        tabla.setItems(observableList);
    }



    @FXML
    void pasarAgregar(MouseEvent event) {
    }

    @FXML
    void quitarAgregar(MouseEvent event) {

    }

}
