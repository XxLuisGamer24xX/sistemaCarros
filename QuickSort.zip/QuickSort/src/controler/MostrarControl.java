package controler;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;

import javafx.scene.input.MouseEvent;
import javafx.scene.paint.Color;
import lista.Lista;

public class MostrarControl {
	Lista lista;
    public Lista getLista() {
		return lista;
	}
	public void setLista(Lista lista) {
		this.lista = lista;
	}

	@FXML
    private Button btMostrar;
    @FXML
    private Label mensajeError;

    @FXML
    void clickMostrar(MouseEvent event) {
    	mensajeError.setText("Mostrando xd");
    	
    	if (lista.estaVacia()) {
    		System.out.println("No se puede mostrar porque está vacía");
    	}
    	else {
    		lista.mostrarLista();
    	}
    }
    @FXML
    void pasarAgregar(MouseEvent event) {
        btMostrar.setStyle("-fx-background-color: #C21010;");
        btMostrar.setTextFill(Color.WHITE);
    }
    @FXML
    void quitarAgregar(MouseEvent event) {
        btMostrar.setStyle("-fx-background-color: black;");
        btMostrar.setTextFill(Color.WHITE);
    }
}
