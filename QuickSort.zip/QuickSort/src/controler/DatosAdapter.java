package controler;

import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import lista.Datos;

public class DatosAdapter {
    private SimpleIntegerProperty id;
    private SimpleStringProperty nombre;
    private SimpleStringProperty apellido;
    private SimpleStringProperty colorCarro;
    private SimpleStringProperty modelo;
    private SimpleDoubleProperty precio;

    public DatosAdapter(Datos datos) {
        this.id = new SimpleIntegerProperty(datos.getCedula());
        this.nombre = new SimpleStringProperty(datos.getNombre());
        this.apellido = new SimpleStringProperty(datos.getApellido());
        this.colorCarro = new SimpleStringProperty(datos.getColorCarro());
        this.modelo = new SimpleStringProperty(datos.getModelo());
        this.precio = new SimpleDoubleProperty(datos.getPrecio());
    }

    public int getId() {
        return id.get();
    }

    public SimpleIntegerProperty idProperty() {
        return id;
    }

    public String getNombre() {
        return nombre.get();
    }

    public SimpleStringProperty nombreProperty() {
        return nombre;
    }

    public String getApellido() {
        return apellido.get();
    }

    public SimpleStringProperty apellidoProperty() {
        return apellido;
    }

    public String getColorCarro() {
        return colorCarro.get();
    }

    public SimpleStringProperty colorCarroProperty() {
        return colorCarro;
    }

    public String getModelo() {
        return modelo.get();
    }

    public SimpleStringProperty modeloProperty() {
        return modelo;
    }

    public double getPrecio() {
        return precio.get();
    }

    public SimpleDoubleProperty precioProperty() {
        return precio;
    }
}
