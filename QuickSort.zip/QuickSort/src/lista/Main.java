package lista;

public class Main {

	public static void main(String[] args) {
	    Lista lista = new Lista();
	    Menu menu = new Menu();
	    menu.menu(lista);
	}
}
